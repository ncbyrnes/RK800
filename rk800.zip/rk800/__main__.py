from rk800.rk800 import run

if __name__ == "__main__":
    run()
