import threading
import queue
from typing import Optional, List


class CommandQueue:
    """Thread-safe command queue for client instructions"""

    def __init__(self, ctx):
        self.ctx = ctx
        self.queue_lock = threading.Lock()
        self.command_queue = queue.Queue()
        self.results_queue = queue.Queue()

    def add_command(self, command):
        """Add a command to the queue with thread safety"""
        with self.queue_lock:
            self.command_queue.put(command)
            self.ctx.view.success(f"Added command to queue: {command.line}")

    def get_next_command(self):
        """Get the next command from the queue with thread safety"""
        with self.queue_lock:
            try:
                return self.command_queue.get_nowait()
            except queue.Empty:
                return None

    def add_result(self, result: str):
        """Add a command result with thread safety"""
        with self.queue_lock:
            self.results_queue.put(result)

    def get_all_results(self) -> List[str]:
        """Get all results and clear the queue with thread safety"""
        with self.queue_lock:
            results = []
            while True:
                try:
                    results.append(self.results_queue.get_nowait())
                except queue.Empty:
                    break
            return results

    def get_queue_status(self) -> dict:
        """Get queue status information with thread safety"""
        with self.queue_lock:
            return {
                "commands_pending": self.command_queue.qsize(),
                "results_pending": self.results_queue.qsize(),
            }
