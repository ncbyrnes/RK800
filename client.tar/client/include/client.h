#ifndef CLIENT_H
#define CLIENT_H

#include "client_config.h"

int StartClient(client_config_t* config);

#endif /*CLIENT_H*/
